# TestOpenGl
---
v 0.0.2
* 更新坦克大战界面
![](assets/markdown-img-paste-20181203203634857.png)

v 0.0.1
* 使用Glut绘图的demo，demo中绘制了文字，直线，矩形，方块，可以用来编写俄罗斯方块。

* 提供响应键盘消息及定时器接口

* 编译环境是VS2015，已包含依赖库glut32.lib/glut32.dll

* 效果如下

![](assets/markdown-img-paste-20181130184300277.png)
